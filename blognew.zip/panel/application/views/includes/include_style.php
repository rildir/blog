<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/bower/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet"
    href="<?php echo base_url("assets"); ?>/libs/bower/material-design-iconic-font/dist/css/material-design-iconic-font.css">
<!-- build:css /assets/css/app.min.css -->
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/bower/animate.css/animate.min.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/bower/fullcalendar/dist/fullcalendar.min.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/libs/bower/perfect-scrollbar/css/perfect-scrollbar.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/assets/css/bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/assets/css/core.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/assets/css/app.css">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/assets/css/custom.css">
<!-- endbuild -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900,300">
<script src="<?php echo base_url("assets"); ?>/libs/bower/breakpoints.js/dist/breakpoints.min.js"></script>
<script>
    Breakpoints();
</script>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url("assets"); ?>/assets/css/dropzone.min.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
