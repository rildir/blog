<?php // application/core/MY_Controller.php
// class MY_Controller extends CI_Controller
// {
//     protected $breadcrumbs = array();

//     public function __construct()
//     {
//         parent::__construct();
//     }

//     protected function add_breadcrumb($title, $link = '')
//     {
//         $this->breadcrumbs[] = array('title' => $title, 'link' => $link);
//     }

//     protected function set_breadcrumbs($breadcrumbs)
//     {
//         $this->breadcrumbs = $breadcrumbs;
//     }

//     public function get_breadcrumbs()
//     {
//         return $this->breadcrumbs;
//     }
// }
?>